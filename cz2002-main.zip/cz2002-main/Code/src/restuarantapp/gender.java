/**
 * Enum for gender
 *
 * @author Nandini Verma
 *
 */

package restuarantapp;

 public enum gender {
	Male, Female
 }
