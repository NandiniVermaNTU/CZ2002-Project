package restuarantapp;

/**
 * @author Lin Zixing
 *
 */


/**
 * Enum for OrderItemTypes
 *
 */
public enum OrderItemType {
	MainCourse, Sides, Drinks, Desserts, Set
}
