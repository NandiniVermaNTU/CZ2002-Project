/**
 * Enum for jobTitle
 *
 ** @author Nandini Verma
 *
 */

package restuarantapp;

  public enum jobTitle {
        Manager, Chef, Server, Dishwasher, Cashier, Receptionist, Barista, Busser, Host, Bartender 
  }
